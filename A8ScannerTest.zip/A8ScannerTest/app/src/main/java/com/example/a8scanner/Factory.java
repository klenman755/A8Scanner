package com.example.a8scanner;
/* Created on 19.1.2016 */


import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;


import androidx.appcompat.app.AppCompatActivity;

import java.io.UnsupportedEncodingException;



/**
 * Podpora zariadenia DL-40 a zaroven aj zariadenia DL-Axist.
 *
 * @author juraj.pacolt
 */
public class Factory  {



    private Context context;

    private Boolean displayNotificationPreviousValue;

    private boolean showToastOnRead = false;

    private BroadcastReceiver receiver;
    private IntentFilter intentFilter;
    private  String PACKAGE_NAME_FISKALPRO_MANAGER = "com.triosoft.a3softfiskal";
    private  int SCAN_ACTIVITY__REQUEST_CODE = 100;
    private  String SCAN_RESULT__INTENT_KEY = "SCAN_RESULT__INTENT_KEY";
    private  String N86_DEVICE_MODEL = "N86";
    private String  N5_DEVICE_MODEL = "N5";

    /**
     * Default konstruktor.
     *
     * @param context
     */
    public Factory(Context context, boolean showToastOnRead) {
        this.context = context;
        this.showToastOnRead = showToastOnRead;


    }

    /**
     * Inicializacia citacky.
     */
    public void init() {
        try {



            Intent intent = new Intent();
            intent.setComponent( new ComponentName(PACKAGE_NAME_FISKALPRO_MANAGER, PACKAGE_NAME_FISKALPRO_MANAGER+".ui.scan.ScanActivity"));
            intent.setAction("ACTION_GET_ACTIVATION_STATUS");
            intent.putExtra("modalProgress", true);
            ((Activity)context).startActivityForResult(intent, SCAN_ACTIVITY__REQUEST_CODE);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace(); // when activity not found check activity path
        }
    }




    /**
     * Zastavenie a uvolnenie citacky.
     */
    public void release() {

    }

    /**
     * Zahajenie citania s default timeoutom.
     */
    public void read() {

    }






}
