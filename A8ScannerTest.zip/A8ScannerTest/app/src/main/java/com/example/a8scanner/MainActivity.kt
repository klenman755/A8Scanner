package com.example.a8scanner

import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

private const val PACKAGE_NAME_FISKALPRO_MANAGER = "com.triosoft.a3softfiskal"
private const val SCAN_ACTIVITY__REQUEST_CODE = 100
private const val SCAN_RESULT__INTENT_KEY = "SCAN_RESULT__INTENT_KEY"

class MainActivity : AppCompatActivity() {






    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
      // startScan()
        findViewById<Button>(R.id.scanB).setOnClickListener {
            //      startScan()
            val f = Factory(this, true)
            f.init()
        }
    }

    private fun startScan() {
        try {
            val intent = Intent()
            intent.component = ComponentName(PACKAGE_NAME_FISKALPRO_MANAGER, "$PACKAGE_NAME_FISKALPRO_MANAGER.ui.scan.ScanActivity")
            intent.action = "ACTION_GET_ACTIVATION_STATUS"
            intent.putExtra("modalProgress", true)
            startActivityForResult(intent, SCAN_ACTIVITY__REQUEST_CODE)
        } catch (e: ActivityNotFoundException) {
            e.printStackTrace() // when activity not found check activity path
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SCAN_ACTIVITY__REQUEST_CODE) {
            val result = data?.getStringExtra(SCAN_RESULT__INTENT_KEY)
            if (result != null) {

                Toast.makeText(this, "Scan result is: ${result}", Toast.LENGTH_LONG).show()
            }
        }
    }
}